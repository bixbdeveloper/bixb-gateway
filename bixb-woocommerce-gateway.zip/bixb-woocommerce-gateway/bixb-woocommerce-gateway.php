<?php
/*
 * Plugin Name: Bixb Woocommerce gateway
 * Plugin URI: https://bix-team.info
 * Description: Bixb Woocommerce payment gateway
 * Version: 1.0
 * Author: Bix-Team
 * Author URI: https://bix-team.info
 * License: Personal use
 * Main Author: Amirhossein Meydani <amirhwsin.ir>
*/

require_once __DIR__ . '/src/class-wc-gateway-bixb.php';

add_action( 'rest_api_init', function() {
    register_rest_route(
        'bixb',
        '/ipn',
        array( 
            'methods' => 'POST',
            'callback' => array(
                'WC_Bixb_Gateway',
                'webhook'
            ),
        )
    );
});